



let filmUrl="http://moviesapi.ir/api/v1/movies/";


//fetch(filmUrl)
   // .then((response) => response.json());
    //.then(jsonData => console.log(jsonData));

let blogsDiv = document.querySelector('#blogs');


async function getmovieFromAPI(Url)
{
    let filmresponse = await fetch(Url);
    let jsonResponse = await filmresponse.json();
    console.log(jsonResponse.data);
    let i=1;
    jsonResponse.data.forEach(async post => {
        let filmdescription = await getFilminfo(Url,post.id);
        let html = `
                     <article>
                           <h2 class="h4">${i} : ${post.title}</h2>
                          <small style="margin-top:10px;" class="badge bg-info">Rating : ${post.imdb_rating}</small>
                            <small style="margin-top:10px;" class="badge bg-primary">Year : ${post.year}</small>
                            <small style="margin-top:10px;" class="badge bg-success">Country : ${post.country}</small>
                            <p style="padding-top:20px;">Description : ${filmdescription.plot}</p>
                     </article>
                     <hr>`;
                 blogsDiv.innerHTML += html;
                 i++;
    })
}



async function getFilminfo(url,id)
{
    let result = await fetch(url+id);
    result = await result.json();
    return result;
}

getmovieFromAPI(filmUrl)
















